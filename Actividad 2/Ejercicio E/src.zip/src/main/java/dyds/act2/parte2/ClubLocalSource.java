package dyds.act2.parte2;

public interface ClubLocalSource {

    Club getClub(int uniqueIdentifier);
    void storeClub(Club a);
}
