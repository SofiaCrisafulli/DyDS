package dyds.act2.parte2;

public interface ClubRemoteSource {

	Club getClubRemote(int uniqueIdentifier);
}
