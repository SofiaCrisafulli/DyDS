package dyds.act2.parte1;

public class Search {

    private String[] search;

    public Search(String[] Search) {
        this.search = Search;
    }

    public String[] getSearch() {
        return search;
    }

    public void setSearch(String[] Search) {
        this.search = Search;
    }
}
