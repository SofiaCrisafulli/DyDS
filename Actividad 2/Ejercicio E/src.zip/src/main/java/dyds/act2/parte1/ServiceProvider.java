package dyds.act2.parte1;

import java.net.URI;

public interface ServiceProvider {

  String resolveCall(URI uri);

}
