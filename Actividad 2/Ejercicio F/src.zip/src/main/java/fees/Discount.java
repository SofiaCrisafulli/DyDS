package fees;

public interface Discount {
    public float applyDiscount(float fractionPrice);
}
