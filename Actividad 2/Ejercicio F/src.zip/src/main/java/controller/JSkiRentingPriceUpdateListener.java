package controller;

public interface JSkiRentingPriceUpdateListener {


  void didUpdateParkingPrice(float price);
}
