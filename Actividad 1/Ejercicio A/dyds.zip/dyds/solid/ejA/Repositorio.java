package dyds.solid.ejA;

public interface Repositorio {
    public boolean grabar(Contenido contenido);
    public int getRepoSizeForTesting();
}
