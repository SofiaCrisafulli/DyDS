package dyds.solid.ejA;

public interface ManejadorRedes {

     public void postearContenido(Contenido contenido);
}
