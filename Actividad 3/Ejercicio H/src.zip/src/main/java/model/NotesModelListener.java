package main.java.model;

public interface NotesModelListener {

    void didUpdateNote();

    void didSelectNote();
}
