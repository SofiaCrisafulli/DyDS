package main.java.views;

import java.awt.*;

public interface NoteListerView extends BaseView {

    public void selectNone();
}
