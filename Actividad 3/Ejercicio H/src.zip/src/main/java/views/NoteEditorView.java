package main.java.views;

import main.java.model.Note;

public interface NoteEditorView extends BaseView {

    void startWaitingStatus();

    void stopWaitingStatus();

    String getUpdateText();

    String getTextContent();

    void cleanFields();

    String getTitle();

    void updateNoteFields(Note note);

    void setTitle(String title);

    void setContent(String content);
}
