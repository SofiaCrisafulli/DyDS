package main.java.utils;

import java.util.Date;

public interface DateManager {
    Date getDate();
}
