package view;

public interface JSkiRentingPriceView {

    public void updatePriceResult(float price);

    public String getShowedPrice();
}
