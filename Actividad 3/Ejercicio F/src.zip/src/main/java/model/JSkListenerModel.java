package model;

public interface JSkListenerModel {
    void itWasCalculatedFee();
}
